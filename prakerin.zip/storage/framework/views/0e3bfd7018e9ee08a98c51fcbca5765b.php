<?php $__env->startSection('content'); ?>
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>
    <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
        <h5 class="h5 mb-0 text-gray-800">Halaman Guru</h5>
    </form>
</nav>

<!-- Tambahkan div pembungkus untuk scrollbar horizontal -->
<div class="table-responsive">
    <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card ml-3" style="width: 18rem;">
            <?php if(!empty($guru->foto) && file_exists(public_path('uploads/gurus/' . $guru->foto))): ?>
                <img src="<?php echo e(asset('uploads/gurus/' . $guru->foto)); ?>" alt="<?php echo e($guru->name); ?>" width="90"
                    class="card-img-top">
            <?php else: ?>
                <img src="<?php echo e(asset('uploads/gurus/nophoto.png')); ?>" alt="<?php echo e($guru->name); ?>" width="90" class="card-img-top">
            <?php endif; ?>
            <div class="card-body">
                <p class="card-text">
                    NIP : <?php echo e($guru->nip); ?><br>
                    Username : <?php echo e($guru->username); ?><br>
                    Nama : <?php echo e($guru->name); ?><br>
                    Password : <?php echo e($guru->password); ?><br>
                    Jenis Kelamin : <?php echo e($guru->jenis_kelamin); ?><br>
                    Phone : <?php echo e($guru->phone); ?><br>
                    Alamat : <?php echo e($guru->alamat); ?><br>
                </p>
                <a class="btn btn-success" href="<?php echo e(route('guru.index')); ?>">Kembali</a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/admin/guru/gurushow.blade.php ENDPATH**/ ?>