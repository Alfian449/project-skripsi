<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <h5 class="h5 mb-0 text-gray-800">Halaman jurusan</h5>
        </form>
    </nav>

    <?php
        $ar_jurusan = ['No', 'Jurusan', 'Action'];
        $no = 1;
    ?>

    <h3 class="ml-3">Data Jurusan</h3>
    <br>

    <div class="row">
        <!-- Bagian Kiri: Tambah, Export, dan Import -->
        <div class="col-lg-8 col-md-7 col-sm-12 mb-3">
            <div class="d-flex flex-wrap">
                <a class="btn btn-primary mb-2 ml-2" href="<?php echo e(route('jurusan.create')); ?>">Tambah</a>
            </div>
        </div>
    </div>

    <!-- Tabel Data Guru -->
    <div class="table-responsive">
        <table class="table table-striped table-hover mt-3 ml-3">
            <thead class="thead-light">
                <tr>
                    <?php $__currentLoopData = $ar_jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ajurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th scope="col"><?php echo e($ajurusan); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($row->nama_jurusan); ?></td>
                        <td>
                            <div class="d-flex flex-column flex-md-row">
                                <form method="POST" action="<?php echo e(route('jurusan.destroy', $row->id)); ?>" onsubmit="return confirm('Apakah Anda Yakin Data Dihapus?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button class="btn btn-danger">Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/admin/jurusan/jurusanindex.blade.php ENDPATH**/ ?>