<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <h5 class="h5 mb-0 text-gray-800">Dashboard Admin</h5>
        </form>
    </nav>

    <div class="container-fluid p-4">
        <h1>Dashboard</h1>
        <?php if(auth()->guard()->check()): ?>
            <h3>Selamat Datang <?php echo e(auth()->user()->username); ?></h3>
        <?php else: ?>
            aku belum login
        <?php endif; ?>
        </div>
        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/dashboard/index.blade.php ENDPATH**/ ?>