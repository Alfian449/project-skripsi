<?php $__env->startSection('content'); ?>
<style>
    /* CSS untuk merapikan tampilan kolom "Tanggung Jawab" dan "Kerja Sama" */
    .table th,
    .table td {
        vertical-align: middle;
        text-align: center;
    }

    .table th {
        white-space: nowrap;
    }

    .table td {
        white-space: nowrap;
    }

    .btn {
        white-space: nowrap;
    }

    .table-responsive {
        overflow-x: auto;
    }

    .ml-3 {
        margin-left: 1rem !important;
    }

    .mt-3 {
        margin-top: 1rem !important;
    }

    .mb-3 {
        margin-bottom: 1rem !important;
    }
</style>

<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>
    <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
        <h5 class="h5 mb-0 text-gray-800">Halaman Rekap Nilai</h5>
    </form>
</nav>

<?php
    $ar_rekapnilai = [
        'No',
        'Nama Siswa',
        'Kelas',
        'Nama Instansi',  // Kolom Nama Instansi
        'Tahun Pelajaran',  // Kolom Tahun Pelajaran yang baru ditambahkan
        'Kedisiplinan',
        'Tanggung Jawab',
        'Komunikasi',
        'Kerja Sama',
        'Inisiatif',
        'Ketekunan',
        'Kreativitas',
        'Action',
    ];
    $no = 1;
?>

<h3 class="ml-3">Data Rekap Nilai</h3>
<br>
<div class="d-flex justify-content-between align-items-start mb-3">
    <div class="d-flex">
        <a class="btn btn-primary ml-3" href="<?php echo e(route('rekapnilai.create')); ?>">Tambah</a>
    </div>
</div>

<div class="table-responsive">
    <table class="table table-striped mt-3 ml-3">
        <thead>
            <tr>
                <?php $__currentLoopData = $ar_rekapnilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arekapnilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th scope="col"><?php echo e($arekapnilai); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rekapnilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($row->user->name); ?></td>
                    <td><?php echo e($row->user->kelas); ?></td>
                    <td>
                        <?php if($row->user->trainings->first() && $row->user->trainings->first()->instansi): ?>
                            <?php echo e($row->user->trainings->first()->instansi->name); ?>

                        <?php else: ?>
                            Tidak ada instansi
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($row->user->tahun_pelajaran); ?></td> <!-- Kolom Tahun Pelajaran -->
                    <td><?php echo e($row->kedisiplinan); ?></td>
                    <td><?php echo e($row->tanggung_jawab); ?></td>
                    <td><?php echo e($row->komunikasi); ?></td>
                    <td><?php echo e($row->kerja_sama); ?></td>
                    <td><?php echo e($row->inisiatif); ?></td>
                    <td><?php echo e($row->ketekunan); ?></td>
                    <td><?php echo e($row->kreativitas); ?></td>
                    <td>
                        <div class="d-flex flex-column flex-md-row">
                            <a class="btn btn-success mb-1 mr-md-1" href="<?php echo e(route('rekapnilai.edit', $row->id)); ?>">Edit</a>
                            <form method="POST" action="<?php echo e(route('rekapnilai.destroy', $row->id)); ?>" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="btn btn-danger" onclick="return confirm('Apakah Anda Yakin Data Dihapus?')">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.halguru', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/guru/rekapnilai/rekapnilaiindex.blade.php ENDPATH**/ ?>