<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <h5 class="h5 mb-0 text-gray-800">Halaman Siswa</h5>
        </form>
    </nav>

    <h3 class="ml-3">Update Siswa</h3>
    <form method="POST" action="<?php echo e(route('siswa.update', $siswa->id)); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div class="form-group ml-3">
            <label>NIS</label>
            <input type="text" name="nis" value="<?php echo e($siswa->nis); ?>" class="form-control">
        </div>

        <div class="form-group ml-3">
            <label>Username</label>
            <input type="text" name="username" value="<?php echo e($siswa->username); ?>" class="form-control">
        </div>

        <div class="form-group ml-3">
            <label>Nama</label>
            <input type="text" name="name" value="<?php echo e($siswa->name); ?>" class="form-control">
        </div>

        <div class="form-group ml-3">
            <label>Password</label>
            <input type="text" name="password" value="<?php echo e($siswa->password); ?>" class="form-control">
        </div>

        <div class="form-group ml-3">
            <label for="kelas">Kelas</label>
            <select class="form-control" name="kelas">
                <option value="">Pilih Kelas</option>
                <option value="XI RPL 1" <?php echo e($siswa->kelas == 'XI RPL 1' ? 'selected' : ''); ?>>XI RPL 1</option>
                <option value="XI RPL 2" <?php echo e($siswa->kelas == 'XI RPL 2' ? 'selected' : ''); ?>>XI RPL 2</option>
                <option value="XI MM 1" <?php echo e($siswa->kelas == 'XI MM 1' ? 'selected' : ''); ?>>XI MM 1</option>
                <option value="XI MM 2" <?php echo e($siswa->kelas == 'XI MM 2' ? 'selected' : ''); ?>>XI MM 2</option>
                <option value="XI DKV 2" <?php echo e($siswa->kelas == 'XI DKV 2' ? 'selected' : ''); ?>>XI DKV 2</option>
            </select>
        </div>

        <div class="form-group ml-3">
            <label for="jenis_kelamin">Jenis Kelamin</label>
            <select class="form-control" name="jenis_kelamin">
                <option value="">Pilih Jenis Kelamin</option>
                <option value="Laki-laki" <?php echo e($siswa->jenis_kelamin == 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                <option value="Perempuan" <?php echo e($siswa->jenis_kelamin == 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
            </select>
        </div>

        <div class="form-group ml-3">
            <label>Phone</label>
            <input type="text" name="phone" value="<?php echo e($siswa->phone); ?>" class="form-control">
        </div>

        <div class="form-group ml-3">
            <label>Alamat</label>
            <input type="text" name="alamat" value="<?php echo e($siswa->alamat); ?>" class="form-control">
        </div>

        <div class="form-group ml-3">
            <label>Foto</label>
            <input type="file" name="foto" class="form-control">
        </div>

        <button type="submit" name="proses" class="btn btn-primary ml-3">Simpan</button>
        <a class="btn btn-success" href="<?php echo e(route('siswa.index')); ?>">Batal</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/admin/siswa/siswaedit.blade.php ENDPATH**/ ?>