<?php $__env->startSection('content'); ?>
<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>
    <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
        <h5 class="h5 mb-0 text-gray-800">Halaman Siswa</h5>
    </form>
</nav>

<?php
    $ar_siswa = ['No', 'NIS', 'Nama', 'Kelas', 'Jenis Kelamin', 'Phone', 'Alamat', 'Foto', 'Action'];
    $no = 1;
?>

<h3 class="ml-3">Data Siswa</h3>
<br>

<div class="row">
    <!-- Bagian Kiri: Tambah, Export, dan Import -->
    <div class="col-lg-8 col-md-7 col-sm-12 mb-3">
        <div class="d-flex flex-wrap">
            <a class="btn btn-primary mb-2 ml-2" href="<?php echo e(route('siswa.create')); ?>">Tambah</a>
            <a class="btn btn-primary ml-2 mb-2" href="<?php echo e(url('siswasi-export')); ?>">Export To Excel</a>
        </div>
        <form action="<?php echo e(route('siswasi.import')); ?>" method="POST" enctype="multipart/form-data" class="d-flex flex-column">
            <?php echo csrf_field(); ?>
            <!-- Kontrol lebar input file dan tombol import -->
            <input type="file" name="file" class="form-control mt-2 col-lg-4 col-md-6 col-sm-12 ml-2">
            <button class="btn btn-success mt-2 col-lg-4 col-md-6 col-sm-12 ml-2">Import Data Siswa</button>
        </form>
    </div>

    <!-- Bagian Kanan: Pencarian -->
    <div class="col-lg-4 col-md-5 col-sm-12">
        <form action="<?php echo e(route('searchsiswa')); ?>" method="GET" class="form-inline">
            <input class="form-control mr-2 mb-2 ml-2" type="text" name="query" placeholder="Search for a name">
            <button class="btn btn-success mb-2 ml-2" type="submit">Search</button>
        </form>
    </div>
</div>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <button id="delete-selected" class="btn btn-danger ml-2">Hapus Data Yang Dipilih</button>
    </div>
</div>

<!-- Tambahkan div pembungkus untuk scrollbar horizontal -->
<div class="table-responsive">
    <table class="table table-striped table-hover mt-3 ml-3">
        <thead class="thead-light">
            <tr>
                <th scope="col"><input type="checkbox" id="select-all-checkbox"></th>
                <?php $__currentLoopData = $ar_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th scope="col"><?php echo e($asiswa); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><input type="checkbox" class="select-item" value="<?php echo e($row->id); ?>"></td>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($row->nis); ?></td>
                    <td><?php echo e($row->name); ?></td>
                    <td><?php echo e($row->kelas); ?></td>
                    <td><?php echo e($row->jenis_kelamin); ?></td>
                    <td><?php echo e($row->phone); ?></td>
                    <td><?php echo e($row->alamat); ?></td>
                    <td>
                        <?php if(!empty($row->foto) && file_exists(public_path('uploads/fotos/' . $row->foto))): ?>
                            <img src="<?php echo e(asset('uploads/fotos/' . $row->foto)); ?>" alt="<?php echo e($row->name); ?>" width="90">
                        <?php else: ?>
                            <img src="<?php echo e(asset('uploads/fotos/nophoto.png')); ?>" alt="<?php echo e($row->name); ?>" width="90">
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="d-flex flex-column flex-md-row">
                            <a class="btn btn-success mb-1 mr-md-1" href="<?php echo e(route('siswa.edit', $row->id)); ?>">Edit</a>
                            <a class="btn btn-info mb-1 mr-md-1" href="<?php echo e(route('siswa.show', $row->id)); ?>">Detail</a>
                            <form method="POST" action="<?php echo e(route('siswa.destroy', $row->id)); ?>" onsubmit="return confirm('Apakah Anda Yakin Data Dihapus?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="btn btn-danger">Hapus</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<script>
document.getElementById('select-all-checkbox').addEventListener('click', function(event) {
    const checkboxes = document.querySelectorAll('.select-item');
    checkboxes.forEach(checkbox => {
        checkbox.checked = event.target.checked;
    });
});

document.getElementById('delete-selected').addEventListener('click', function() {
    const selected = Array.from(document.querySelectorAll('.select-item:checked')).map(cb => cb.value);
    if (selected.length > 0) {
        if (confirm('Apakah Anda yakin ingin menghapus data siswa yang dipilih?')) {
            fetch('<?php echo e(route('siswas.massDelete')); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({ ids: selected })
            }).then(response => response.json())
              .then(data => {
                  if (data.success) {
                      location.reload();
                  } else {
                      alert('Terjadi kesalahan saat menghapus data.');
                  }
              })
              .catch(error => console.error('Error:', error));
        }
    } else {
        alert('Pilih setidaknya satu siswa untuk dihapus.');
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/admin/siswa/siswaindex.blade.php ENDPATH**/ ?>