<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <h5 class="h5 mb-0 text-gray-800">Halaman Rekap Nilai - Hasil Pencarian</h5>
        </form>
    </nav>

    <?php
    $ar_rekapnilai = [
        'No',
        'Nama Siswa',
        'Kelas',
        'Nama Instansi',  // Kolom Nama Instansi
        'Tahun Pelajaran',  // Kolom Tahun Pelajaran yang baru ditambahkan
        'Kedisiplinan',
        'Tanggung Jawab',
        'Komunikasi',
        'Kerja Sama',
        'Inisiatif',
        'Ketekunan',
        'Kreativitas',
    ];
    $no = 1;
?>

    <h3 class="ml-3">Hasil Pencarian Rekap Nilai</h3>
    <nav aria-label="breadcrumb" class="ml-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/rekap-nilai')); ?>">Back</a></li>
            <li class="breadcrumb-item active" aria-current="page">Hasil Pencarian</li>
        </ol>
    </nav>



    <!-- Tambahkan div pembungkus untuk scrollbar horizontal -->
    <div class="table-responsive">
        <table class="table table-striped mt-3 ml-3">
            <thead>
                <tr>
                    <?php $__currentLoopData = $ar_rekapnilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arekapnilai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th scope="col"><?php echo e($arekapnilai); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $resultRekapNilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($row->user->name); ?></td>
                        <td><?php echo e($row->user->kelas); ?></td>
                        <td>
                            <?php if($row->user->trainings->first() && $row->user->trainings->first()->instansi): ?>
                                <?php echo e($row->user->trainings->first()->instansi->name); ?>

                            <?php else: ?>
                                Tidak ada instansi
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($row->user->tahun_pelajaran); ?></td> <!-- Kolom Tahun Pelajaran -->
                        <td><?php echo e($row->kedisiplinan); ?></td>
                        <td><?php echo e($row->tanggung_jawab); ?></td>
                        <td><?php echo e($row->komunikasi); ?></td>
                        <td><?php echo e($row->kerja_sama); ?></td>
                        <td><?php echo e($row->inisiatif); ?></td>
                        <td><?php echo e($row->ketekunan); ?></td>
                        <td><?php echo e($row->kreativitas); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/search/resultrekapnilai.blade.php ENDPATH**/ ?>