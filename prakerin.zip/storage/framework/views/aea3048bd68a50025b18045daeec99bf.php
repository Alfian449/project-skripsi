<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <h5 class="h5 mb-0 text-gray-800">LogBook Kegiatan Siswa</h5>
        </form>
    </nav>

    <?php
        $ar_monitoring = ['No', 'Nama Kegiatan', 'Keterangan', 'Tanggal',];
        $no = 1;
    ?>

    <h3 class="ml-3">Logbook Kegiatan Siswa</h3>
    <br>
    <div class="d-flex justify-content-between align-items-center mb-3">
        <form action="<?php echo e(route('searchlogbook')); ?>" method="GET" class="form-inline">
            <input class="form-control mr-2" type="text" name="query" placeholder="Search for a name">
            <button class="btn btn-success" type="submit">Search</button>
        </form>
    </div>

    <table class="table table-striped mt-3 ml-3">
        <thead>
            <tr>
                <?php $__currentLoopData = $ar_monitoring; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amonitoring): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th scope="col"><?php echo e($amonitoring); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $monitoring; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($row->user->name); ?></td>
                    <td><?php echo e($row->nama_kegiatan); ?></td>
                    <td><?php echo e($row->keterangan); ?></td>
                    <td><?php echo e($row->tanggal); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.halsiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/siswa/monitoring/monitoringindex.blade.php ENDPATH**/ ?>