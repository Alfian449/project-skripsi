<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <h5 class="h5 mb-0 text-gray-800">Halaman Instansi</h5>
        </form>
    </nav>

    <h3 class="ml-3">Update Instansi</h3>
    <form method="POST" action="<?php echo e(route('instansi.update', $instansi->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group ml-3">
            <label>Nama</label>
            <input type="text" name="name" value="<?php echo e($instansi->name); ?>" class="form-control">
        </div>

        <div class="form-group ml-3">
            <label>Alamat</label>
            <input type="text" name="alamat" value="<?php echo e($instansi->alamat); ?>" class="form-control">
        </div>

        <div class="form-group ml-3">
            <label>Phone</label>
            <input type="text" name="phone" value="<?php echo e($instansi->phone); ?>" class="form-control">
        </div>

        <div class="form-group ml-3">
            <label>Email</label>
            <input type="email" name="email" value="<?php echo e($instansi->email); ?>" class="form-control">
        </div>

        <div class="form-group ml-3">
            <label>Penanggung Jawab</label>
            <select name="guru_id" class="form-control">
                <?php $__currentLoopData = $pilihpenanggungjawab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($guru->id); ?>" <?php echo e($instansi->guru_id == $guru->id ? 'selected' : ''); ?>>
                        <?php echo e($guru->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <button type="submit" name="proses" class="btn btn-primary ml-3">Simpan</button>
        <a class="btn btn-success" href="<?php echo e(route('instansi.index')); ?>">Batal</a>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/admin/instansi/instansiedit.blade.php ENDPATH**/ ?>