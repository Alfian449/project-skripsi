<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <h5 class="h5 mb-0 text-gray-800">Halaman Monitoring Siswa</h5>
        </form>
    </nav>

    <?php
        $ar_monitoring = ['No', 'Instansi', 'Nama Siswa', 'NIS', 'Tahun Pelajaran', 'Kelas', 'Tanggal', 'Keterangan','Action'];
        $no = 1;
    ?>

    <h3 class="ml-3">Data Monitoring Siswa</h3>
    <br>

    <!-- Tambahkan div pembungkus untuk scrollbar horizontal -->
    <div class="table-responsive">
    <table class="table table-striped mt-3 ml-3">
        <thead>
            <tr>
                <?php $__currentLoopData = $ar_monitoring; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amonitoring): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th scope="col"><?php echo e($amonitoring); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $monitoring; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($row->training->instansi->name); ?></td>
                    <td><?php echo e($row->user->name); ?></td>
                    <td><?php echo e($row->user->nis); ?></td>
                    <td><?php echo e($row->user->tahun_pelajaran); ?></td>
                    <td><?php echo e($row->user->kelas); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($row->tanggal)->format('d-m-Y')); ?></td>
                    <td><?php echo e($row->keterangan); ?></td>
                    <td>
                        <?php if($row->status == 'pending'): ?>
                            <form method="POST" action="<?php echo e(route('logbook.approve', $row->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-success">Approve</button>
                            </form>
                        <?php else: ?>
                            <span class="badge badge-success">Approved</span>
                        <?php endif; ?>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.halguru', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/guru/monitoring/monitoringindex.blade.php ENDPATH**/ ?>