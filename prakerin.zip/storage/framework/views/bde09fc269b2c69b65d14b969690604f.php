<!DOCTYPE html>
<html>
<head>
    <title>Laravel 10 Generate PDF Example - ItSolutionStuff.com</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <p><?php echo e($date); ?></p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua.</p>

    <table class="table table-bordered">
        <tr>
            <th>Nama Siswa</th>
            <th>Kedisiplinan</th>
            <th>Tanggung Jawab</th>
            <th>Komunikasi</th>
            <th>Kerja Sama</th>
            <th>inisiatif</th>
            <th>Ketekunan</th>
            <th>Kreativitas</th>
        </tr>
        <?php $__currentLoopData = $rekapnilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->kedisiplinan); ?></td>
            <td><?php echo e($user->tanggung_jawab); ?></td>
            <td><?php echo e($user->komunikasi); ?></td>
            <td><?php echo e($user->kerja_sama); ?></td>
            <td><?php echo e($user->inisiatif); ?></td>
            <td><?php echo e($user->ketekunan); ?></td>
            <td><?php echo e($user->kreativitas); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</body>
</html>
<?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/myPDF.blade.php ENDPATH**/ ?>