<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <h5 class="h5 mb-0 text-gray-800">LogBook Kegiatan</h5>
        </form>
    </nav>

    <h3 class="ml-3">Update LogBook</h3>
    <form method="POST" action="<?php echo e(route('logbook.update', $logbook->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        

        <div class="form-group ml-3">
            <label>Keterangan</label>
            <input type="text" name="keterangan" value="<?php echo e($logbook->keterangan); ?>" class="form-control">
        </div>

        <div class="form-group ml-3">
            <label>Tanggal</label>
            <input type="date" name="tanggal" value="<?php echo e($logbook->tanggal); ?>" class="form-control">
        </div>


        <button type="submit" name="proses" class="btn btn-primary ml-3">Simpan</button>
        
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.halsiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/siswa/logbook/logbookedit.blade.php ENDPATH**/ ?>