<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <h5 class="h5 mb-0 text-gray-800">Halaman Ploting Prakerin</h5>
        </form>
    </nav>

    <?php
        $ar_training = ['No', 'Nama Siswa', 'NIS', 'Tahun Pelajaran', 'Nama Instansi', 'Penanggung Jawab', 'Jurusan', 'Aksi'];
        $no = 1;
    ?>

    <h3 class="ml-3">Data Ploting Prakerin</h3>
    <br>

    <div class="row">
        <div class="col-lg-8 col-md-7 col-sm-12 mb-3">
            <div class="d-flex flex-wrap">
                <a class="btn btn-primary ml-2 mb-2" href="<?php echo e(url('plotingprakerin-export')); ?>">Export To Excel</a>

                <form action="" method="get" class="form-inline">
                    <!-- Filter Instansi -->
                    <select class="form-control mr-2 mb-2 ml-2" name="p">
                        <option value="" selected>Pilih Instansi</option>
                        <?php $__currentLoopData = $pilihinstansi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e(request()->get('p') == $item->id ? 'selected' : ''); ?>>
                                <?php echo e($item->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <!-- Filter Tahun Pelajaran -->
                    <select class="form-control mr-2 mb-2 ml-2" name="t">
                        <option value="" selected>Pilih Tahun Pelajaran</option>
                        <?php $__currentLoopData = $tahunPelajaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tahun->tahun_pelajaran); ?>" <?php echo e(request()->get('t') == $tahun->tahun_pelajaran ? 'selected' : ''); ?>>
                                <?php echo e($tahun->tahun_pelajaran); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <button class="btn btn-success mb-2 ml-2" type="submit">Filter</button>
                </form>
            </div>
        </div>

        <div class="col-lg-4 col-md-5 col-sm-12">
            <form action="<?php echo e(route('searchploting')); ?>" method="GET" class="form-inline">
                <input class="form-control mr-2 mb-2 ml-2" type="text" name="query" placeholder="Search for a name">
                <button class="btn btn-success mb-2 ml-2" type="submit">Search</button>
            </form>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-striped mt-3 ml-3">
            <thead>
                <tr>
                    <?php $__currentLoopData = $ar_training; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atraining): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th scope="col"><?php echo e($atraining); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $training; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($row->user->name); ?></td>
                        <td><?php echo e($row->user->nis); ?></td>
                        <td><?php echo e($row->user->tahun_pelajaran); ?></td>
                        <td><?php echo e($row->instansi->name); ?></td>
                        <td><?php echo e($row->instansi->guru->name); ?></td>
                        <td><?php echo e($row->user->kelas); ?></td>
                        <td>
                            <!-- Status dan aksi -->
                            <div class="d-flex align-items-center">
                                <span class="mr-2">
                                    <?php if($row->status == 'approved'): ?>
                                        <span class="text-success"><?php echo e(ucfirst($row->status)); ?></span>
                                    <?php elseif($row->status == 'pending'): ?>
                                        <span class="text-warning"><?php echo e(ucfirst($row->status)); ?></span>
                                    <?php else: ?>
                                        <span class="text-danger"><?php echo e(ucfirst($row->status)); ?></span>
                                    <?php endif; ?>
                                </span>

                                <?php if($row->status == 'pending'): ?>
                                    <form action="<?php echo e(route('training.approve', $row->id)); ?>" method="POST" class="mr-1">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-success">Approve</button>
                                    </form>
                                    <form action="<?php echo e(route('training.reject', $row->id)); ?>" method="POST" class="mr-1">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-danger">Reject</button>
                                    </form>
                                <?php else: ?>
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-sm btn-warning" data-toggle="modal"
                                        data-target="#editTraining<?php echo e($row->id); ?>">
                                        Edit
                                    </button>
                                <?php endif; ?>
                            </div>

                            <!-- Modal -->
                            <div class="modal fade" id="editTraining<?php echo e($row->id); ?>" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="modalCamp">
                                                Edit Status Training <?php echo e($row->user->name); ?>

                                            </h5>
                                            <button class="close" type="button" data-dismiss="modal"
                                                aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                            </button>
                                        </div>
                                        <form action="<?php echo e(route('list-training.update', $row->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label for="status"> Status</label>
                                                    <select class="form-control" name="status">
                                                        <option value="approved" <?php echo e($row->status == 'approved' ? 'selected' : ''); ?>>Approved</option>
                                                        <option value="pending" <?php echo e($row->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
                                                        <option value="rejected" <?php echo e($row->status == 'rejected' ? 'selected' : ''); ?>>Rejected</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary">Simpan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/admin/training/trainingindex.blade.php ENDPATH**/ ?>