<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <h5 class="h5 mb-0 text-gray-800">Halaman List Training</h5>
        </form>
    </nav>

    <?php
        $ar_training = ['No', 'Nama Siswa', 'Nama Instansi', 'Jurusan', 'Status', 'Aksi'];
        $no = 1;
    ?>

    <h3 class="ml-3">Data List Training</h3>
    <br>

    <!-- Tambahkan div pembungkus untuk scrollbar horizontal -->
    <div class="table-responsive">
        <table class="table table-striped mt-3 ml-3">
            <thead>
                <tr>
                    <?php $__currentLoopData = $ar_training; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atraining): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th scope="col"><?php echo e($atraining); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $training; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($row->user->name); ?></td>
                        <td><?php echo e($row->instansi->name); ?></td>
                        <td><?php echo e($row->jurusan); ?></td>
                        <td><?php echo e($row->status); ?></td>
                        <td>
                            <?php if($row->status == 'pending'): ?>
                                <form action="<?php echo e(route('training.approve', $row->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-success">Approve</button>
                                </form>
                            <?php else: ?>
                                Approved
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/admin/training/trainingindex.blade.php ENDPATH**/ ?>