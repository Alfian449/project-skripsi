<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <h5 class="h5 mb-0 text-gray-800">Halaman Rekap Nilai</h5>
        </form>
    </nav>

    <h3 class="ml-3">Update Rekap Nilai</h3>
    <?php $__currentLoopData = $rekapnilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form method="POST" action="<?php echo e(route('rekapnilai.update', $rn->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="form-group ml-3">
                <label>Nama</label>
                <input type="text" name="name" value="<?php echo e($rn->name); ?>" class="form-control">
            </div>

            <div class="form-group ml-3">
                <label>Kedisiplinan</label>
                <input type="text" name="kedisiplinan" value="<?php echo e($rn->kedisiplinan); ?>" class="form-control">
            </div>

            <div class="form-group ml-3">
                <label>Tanggung Jawab</label>
                <input type="text" name="tanggung_jawab" value="<?php echo e($rn->tanggung_jawab); ?>" class="form-control">
            </div>

            <div class="form-group ml-3">
                <label>Komunikasi</label>
                <input type="text" name="komunikasi" value="<?php echo e($rn->komunikasi); ?>" class="form-control">
            </div>

            <div class="form-group ml-3">
                <label>Kerja Sama</label>
                <input type="text" name="kerja_sama" value="<?php echo e($rn->kerja_sama); ?>" class="form-control">
            </div>

            <div class="form-group ml-3">
                <label>Inisiatif</label>
                <input type="text" name="inisiatif" value="<?php echo e($rn->inisiatif); ?>" class="form-control">
            </div>

            <div class="form-group ml-3">
                <label>Ketekunan</label>
                <input type="text" name="ketekunan" value="<?php echo e($rn->ketekunan); ?>" class="form-control">
            </div>

            <div class="form-group ml-3">
                <label>Kreativitas</label>
                <input type="text" name="kreativitas" value="<?php echo e($rn->kreativitas); ?>" class="form-control">
            </div>

            <button type="submit" name="proses" class="btn btn-primary ml-3">Simpan</button>
            <a class="btn btn-success" href="<?php echo e(route('siswa.index')); ?>">Batal</a>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.halguru', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/guru/rekapnilai/rekapnilaiedit.blade.php ENDPATH**/ ?>