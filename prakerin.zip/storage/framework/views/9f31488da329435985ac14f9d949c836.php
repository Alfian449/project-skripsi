<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <h5 class="h5 mb-0 text-gray-800">Admin</h5>
        </form>
    </nav>

    <style>
        .table-container {
            overflow-x: auto;
            max-width: 100%;
        }
    </style>

    <div>
        <h2 class="ml-3">Data Guru</h2>
        <nav aria-label="breadcrumb" class="ml-3">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/guru')); ?>">Back</a></li>
                <li class="breadcrumb-item active" aria-current="page">Hasil Pencarian</li>
            </ol>
        </nav>
        <div class="table-container">
            <table class="table table-striped mt-3 ml-3">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th>NIP</th>
                        <th>Username</th>
                        <th>Nama</th>
                        <th>Jenis Kelamin</th>
                        <th>Phone</th>
                        <th>Alamat</th>
                        <th>Foto</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $resultsguru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($result->nip); ?></td>
                            <td><?php echo e($result->username); ?></td>
                            <td><?php echo e($result->name); ?></td>
                            <td><?php echo e($result->jenis_kelamin); ?></td>
                            <td><?php echo e($result->phone); ?></td>
                            <td><?php echo e($result->alamat); ?></td>
                            <td>
                                <?php if(!empty($result->foto) && file_exists(public_path('uploads/gurus/' . $result->foto))): ?>
                                    <img src="<?php echo e(asset('uploads/gurus/' . $result->foto)); ?>" alt="<?php echo e($result->name); ?>" width="90">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('uploads/gurus/nophoto.png')); ?>" alt="<?php echo e($result->name); ?>" width="90">
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="d-flex">
                                    <a class="btn btn-success mr-1" href="<?php echo e(route('guru.edit', $result->id)); ?>">Edit</a>
                                    <a class="btn btn-info mr-1" href="<?php echo e(route('guru.show', $result->id)); ?>">Detail</a>
                                    <form method="POST" action="<?php echo e(route('guru.destroy', $result->id)); ?>" onsubmit="return confirm('Apakah Anda Yakin Data Dihapus?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button class="btn btn-danger">Hapus</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/search/resultsguru.blade.php ENDPATH**/ ?>