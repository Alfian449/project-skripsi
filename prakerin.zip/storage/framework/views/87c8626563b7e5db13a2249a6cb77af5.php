<?php $__env->startSection('content'); ?>
    <div class="row ml-3 mt-3">
        <?php if($history): ?>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($history->instansi->name); ?></h5>
                    <div class="card-text"><?php echo e($history->instansi->email); ?> | <?php echo e($history->instansi->phone); ?></div>
                    <div class="card-text"><?php echo e($history->instansi->alamat); ?></div>
                    <?php if($history->status == 'approved'): ?>
                        <a href="<?php echo e(route('trainings.show', $history->id)); ?>"
                            class="btn mt-3 <?php echo e($history->status == 'approved' ? 'btn-success' : ($history->status == 'pending' ? 'btn-warning' : 'btn-danger')); ?>">Logbook</a>
                    <?php else: ?>
                        <button class="btn btn-secondary mt-3" disabled>Logbook</button>
                    <?php endif; ?>
                </div>
                <?php if($history->status == 'approved'): ?>
                    <div class="card-footer text-success">
                        <h7 class="text-success font-italic">Pilihan Instansi Anda Diapproved Oleh Admin</h7>
                    </div>
                <?php elseif($history->status == 'pending'): ?>
                    <div class="card-footer text-warning">
                        <h7 class="text-warning
                            font-italic">Harap Menunggu Pilihan Instansi Anda DiApproved Oleh Admin</h7>
                    </div>
                <?php else: ?>
                    <div class="card-footer text-danger">
                        <h7 class="text-danger
                            font-italic">Pilihan Instansi Anda Ditolak Oleh Admin. Silahkan Memilih Instansi Lain</h7>
                    </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <p class="ml-3">Belum ada instansi yang dipilih.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.halsiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/siswa/history/historyindex.blade.php ENDPATH**/ ?>