<?php $__env->startSection('content'); ?>
    <div class="row ml-3 mt-3">
        <?php if($history): ?>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($history->instansi->name); ?></h5>
                    <div class="card-text"><?php echo e($history->instansi->email); ?> | <?php echo e($history->instansi->phone); ?></div>
                    <div class="card-text"><?php echo e($history->instansi->alamat); ?></div>
                    <a href="<?php echo e(route('trainings.show', $history->id)); ?>" class="btn btn-primary">Logbook</a>
                </div>
            </div>
        <?php else: ?>
            <p class="ml-3">Belum ada instansi yang dipilih.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.halsiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/siswa/history/historyindex.blade.php ENDPATH**/ ?>