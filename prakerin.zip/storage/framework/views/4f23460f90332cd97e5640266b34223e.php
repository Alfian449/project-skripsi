<?php $__env->startSection('content'); ?>
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
        </button>
        <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <h5 class="h5 mb-0 text-gray-800">Halaman Pilih Instansi</h5>
        </form>
    </nav>

    <h3 class="ml-3">Magang</h3>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('trainings.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group ml-3">
            <input type="hidden" name="user_id" value="<?php echo e(auth()->id()); ?>">
            <label>Nama Siswa</label>
            <input type="text" name="name" value="<?php echo e(auth()->user()->name); ?>" class="form-control" readonly>
        </div>

        <div class="form-group ml-3">
            <input type="hidden" name="user_id" value="<?php echo e(auth()->id()); ?>">
            <label>NIS</label>
            <input type="text" name="nis" value="<?php echo e(auth()->user()->nis); ?>" class="form-control" readonly>
        </div>

        <div class="form-group ml-3">
            <input type="hidden" name="user_id" value="<?php echo e(auth()->id()); ?>">
            <label>Kelas</label>
            <input type="text" name="kelas" value="<?php echo e(auth()->user()->kelas); ?>" class="form-control" readonly>
        </div>

        <div class="form-group ml-3">
            <label for="instansi">Pilihan Instansi 1</label>
            <select class="form-control" name="instansi_id">
                <option value="" selected>Pilih Instansi</option>
                <?php $__currentLoopData = $pilihinstansi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <button type="submit" name="proses" class="btn btn-primary ml-3">Simpan</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.halsiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\app-pkl - Copy\resources\views/siswa/instansi/pilihinstansi.blade.php ENDPATH**/ ?>